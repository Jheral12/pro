<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
 <div class="page-header breadcrumb-wrap">
                <div class="container">
                    <div id="breadcrumb" class="breadcrumb">
                        <a href="<?php echo base_url ('/');?>" rel="nofollow"><i class="fi-rs-home mr-5"></i>Hogar</a>
                        <span></span>Pagina<span></span>Mi cuenta
                    </div>
                </div>
            </div>
            <div class="page-content pt-150 pb-150">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-10 m-auto">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="dashboard-menu">
                                        <ul class="nav flex-column" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" id="dashboard-tab" data-bs-toggle="tab" href="#dashboard" role="tab" aria-controls="dashboard" aria-selected="false"><i class="fi-rs-settings-sliders mr-10"></i>Tablero</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="productos-tab" data-bs-toggle="tab" href="#productos" role="tab" aria-controls="productos" aria-selected="false"><i class="fi-rs-shopping-bag mr-10"></i>Productos</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="address-tab" data-bs-toggle="tab" href="#clientes" role="tab" aria-controls="address" aria-selected="true"><i class="fi-rs-marker mr-10"></i>Clientes</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="account-detail-tab" data-bs-toggle="tab" href="#account-detail" role="tab" aria-controls="account-detail" aria-selected="true"><i class="fi-rs-user mr-10"></i>Detalles de la cuenta</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="<?php echo base_url ('salir');?>"><i class="fi-rs-sign-out mr-10"></i>Cerrar sesión</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-9">
                                    <div class="tab-content account dashboard-content pl-50">
                                        <div class="tab-pane fade active show" id="dashboard" role="tabpanel" aria-labelledby="dashboard-tab">
                                            <div class="card">
                                                <div class="card-header">
                                                <h3 class="mb-2">Hola <?php echo $this->session->userdata('tx_usuario');?>!</h3>
                                                    <h5 class="mb-0 fw-light"><?php echo $this->session->userdata('nb_rol_usuario');?></h5>
                                                </div>
                                                <div class="card-body">
                                                    <p>
                                                        Desde el panel de su cuenta. puede comprobar fácilmente ver sus <a href="#">órdenes recientes</a>,<br />
                                                        administrar su <a href="#">direccion de envío y facturación</a> y <a href="#">edite su contraseña y los detalles de su cuenta.</a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="productos" role="tabpanel" aria-labelledby="orders-tab">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h3 class="mb-3">Productos</h3>
                                            <form id="frm-save-producto" method="post">
                                                <div class="form-group">
                                                    <input type="hidden" id="id_producto" name="id">
                                                    <input type="text" required="" id="p_descripcion" name="descripcion" placeholder="Titulo" />
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" required="" id="p_precio" name="precio" placeholder="precio" />
                                                </div>

                                                <div class="form-group">
                                                <select class="form-select" required="Seleccione Categoria" id="p_categoria" name="categoria" aria-label="select categoria">
                                                    <option value="" selected>seleccione categoria</option>
                                                    <option value="1">Victoria's Secret</option>
                                                    <option value="2">Street Looks</option>
                                                    <option value="3">Charm</option>
                                                    <option value="4">Mirage</option>
                                                    <option value="5">Concept II</option>
                                                    </select>
                                                </div>

                                                <div class="form-group">
                                                    <input type="text" required="" id="p_foto" name="foto" placeholder="link de foto" />
                                                </div>
        
                                                <div class="form-group mb-30">
                                                    <button type="submit" class="btn btn-fill-out btn-block hover-up font-weight-bold" name="producto">Guardar</button>
                                                    <button type="reset"  class="btn btn-fill-out btn-block hover-up font-weight-bold" name="producto">Limpiar</button>
                                                </div>
                                            </form>
                                                </div>
                                                <div class="card-body">
                                                   <div class="table-responsive table-striped">
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>id</th>
                                                                    <th>Descripcion</th>
                                                                    <th>Precio</th>
                                                                    <th>Foto</th>
                                                                    <th>Acciones</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <? foreach($lstall_producto as $row){ ?>
                                                                <tr>
                                                            <td> #<?php echo $row->id;?></td>
                                                            <td> <?php echo $row->tx_titulo_producto;?></td>
                                                            <td> <?php echo $row->nu_precio_producto;?></td>
                                                            <td> <img src="<?php base_url();?>assets/imgs/shop/<?php echo $row->tx_url_foto_producto;?>" alt="<?php echo $row->tx_titulo_producto;?>" width="100px"></td>
                                                            <td><a href="#breadcrumb" data-id="<?php echo $row->id;?>" data-descripcion="<?php echo $row->tx_titulo_producto;?>" data-precio="<?php echo $row->nu_precio_producto;?>" data-foto="<?php echo $row->tx_url_foto_producto ;?>" data-categoria="<?php echo $row->nu_categoria_producto_id;?>" class="btn-upd-producto btn btn-small btn-success d-block">Editar</a></td>
                                                            <td><button data-id="<?php echo $row->id;?>" class="btn-del-producto btn btn-small btn-success d-block">Borrar</button></td>
                                                        </tr>
                                                            <? } ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="clientes" role="tabpanel" aria-labelledby="address-tab">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="card mb-3 mb-lg-0">
                                                        <div class="card-header">
                                                            <h3 class="mb-0">Dirección de Envio</h3>
                                                        </div>
                                                        <div class="card-body">
                                                            <address>
                                                                Villavicensio<br />
                                                                y tunupa<br />
                                                                #6551
                                                            </address>
                                                            <p>Cochabamba</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="card">
                                                        <div class="card-header">
                                                            <h5 class="mb-0">Dirección de Envío</h5>
                                                        </div>
                                                        <div class="card-body">
                                                            <address>
                                                                Telefono: 70794891
                                                            </address>
                                                            <p>Cochabamba</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="account-detail" role="tabpanel" aria-labelledby="account-detail-tab">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5>Detalles de la Cuenta</h5>
                                                </div>
                                                <div class="card-body">
                                                    <p>¿Ya tienes una cuenta?<a href="page-login.html">¡Inicie sesión!</a></p>
                                                    <form method="post" name="enq">
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label>Primer nombre <span class="required">*</span></label>
                                                                <input required="" class="form-control" name="name" type="text" />
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Apellido <span class="required">*</span></label>
                                                                <input required="" class="form-control" name="phone" />
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label>Nombre para mostrar <span class="required">*</span></label>
                                                                <input required="" class="form-control" name="dname" type="text" />
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label>Dirección de correo electrónico <span class="required">*</span></label>
                                                                <input required="" class="form-control" name="email" type="email" />
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label>Contraseña actual<span class="required">*</span></label>
                                                                <input required="" class="form-control" name="password" type="password" />
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label>Nueva contraseña<span class="required">*</span></label>
                                                                <input required="" class="form-control" name="npassword" type="password" />
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label>Confirmar Contraseña <span class="required">*</span></label>
                                                                <input required="" class="form-control" name="cpassword" type="password" />
                                                            </div>
                                                            <div class="col-md-12">
                                                                <button type="submit" class="btn btn-fill-out submit font-weight-bold" name="submit" value="Submit">Guardar cambios</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>