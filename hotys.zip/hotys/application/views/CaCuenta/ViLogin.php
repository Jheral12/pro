<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
 <div class="page-header breadcrumb-wrap">
                <div class="container">
                    <div class="breadcrumb">
                        <a href="index" rel="nofollow"><i class="fi-rs-home mr-5"></i>Hogar</a>
                        <span></span>Paginas<span></span>Acceso
                    </div>
                </div>
            </div>
            <div class="page-content pt-150 pb-150">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8 col-lg-10 col-md-12 m-auto">
                            <div class="row">
                                <div class="col-lg-6 pr-30 d-none d-lg-block">
                                    <img class="border-radius-15" src="<?php base_url();?>assets/imgs/theme/icons/3094352.jpg" alt="" />
                                </div>
                                <div class="col-lg-6 col-md-8">
                                    <div class="login_wrap widget-taber-content background-white">
                                        <div class="padding_eight_all bg-white">
                                            <div class="heading_s1">
                                                <h1 class="mb-5">Acceso</h1>
                                                <p class="mb-30">¿No tienes una cuenta? <a href="<?php echo base_url ('signin');?>">Crea aqui</a></p>
                                            </div>
                                            <form id="frmingreso" method="post">
                                               <div class="form-group">
                                               <input type="hidden" name="tx_token" value="<?php echo $tx_token;?>">
                                                    <input type="email" placeholder="Correo electrónico" name="emailIngreso" id="emailIngreso" autocomplete="on" required/>
                                                </div>
                                                <div class="form-group">
                                                    <input type="password" placeholder="Tu contraseña" name="passwordIngreso" id="passwordIngreso" autocomplete="on" required/>
                                                </div>
                                                <div class="login_footer form-group mb-50">
                                                    <div class="chek-form">
                                                        <div class="custome-checkbox">
                                                            <input class="form-check-input" type="checkbox" name="checkbox" id="exampleCheckbox1" value="" />
                                                            <label class="form-check-label" for="exampleCheckbox1"><span>Recuérdame</span></label>
                                                        </div>
                                                    </div>
                                                    <a class="text-muted" href="pagerecovery">¿Se te olvidó tu contraseña?</a>
                                                </div>
                                               
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-heading btn-block hover-up" name="frmingreso">Iniciar sesión</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>