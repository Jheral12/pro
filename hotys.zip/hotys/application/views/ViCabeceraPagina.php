<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html class="no-js" lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="Perfumes y Fragancias" />
		<meta property="og:title" content="HOTY'S" />
		<meta property="og:description" content="Perfumes y Fragancias" />
		<meta property="og:image" content="<?= base_url();?>assets/imgs/oghotys.png" />

		<title>HOTY'S</title>
		<meta http-equiv="x-ua-compatible" content="ie=edge" />
		<meta name="description" content="" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta property="og:title" content="" />
		<meta property="og:type" content="" />
		<meta property="og:url" content="" />
		<meta property="og:image" content="" />
		<!-- Favicon -->
		<link rel="shortcut icon" type="image/x-icon" href="<?php base_url();?>assets/imgs/theme/1.png" />

		<!-- Template CSS -->
		<link rel="stylesheet" href="<?php base_url();?>assets/css/plugins/animate.min.css" />
		<link rel="stylesheet" href="<?php base_url();?>assets/css/main.css?v=2.0" />
     	<!-- Sweetalert 2 -->
		<link rel="stylesheet" href="<?php echo base_url ();?>assets/css/plugins/sweetalert2.min.css">
   		<!-- page css custom  -->
  		<?php if(@$css){ foreach ($css as $c) {?> <link rel="stylesheet" href="<?php echo base_url(); ?><?php echo $c?>"><?} } ?>   
   		<!-- page css custom  -->
   		<script type="text/javascript">const baseurl = '<?php echo base_url ();?>'; //home de la web</script>
	</head>
        <body>


		<!-- Quick view -->
		<div class="modal fade custom-modal" id="quickViewModal" tabindex="-1" aria-labelledby="quickViewModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					<div class="modal-body">
						<div class="row">
							<div class="col-md-6 col-sm-12 col-xs-12 mb-md-0 mb-sm-5">
								<div class="detail-gallery">
									<span class="zoom-icon"><i class="fi-rs-search"></i></span>
									<!-- MAIN SLIDES -->
									<div class="product-image-slider">
										<figure class="border-radius-10">
											<img src="<?php base_url();?>assets/imgs/shop/pr1.jpg" alt="product image" />
										</figure>
										<figure class="border-radius-10">
											<img src="<?php base_url();?>assets/imgs/shop/pr2.jpg" alt="product image" />
										</figure>
										<figure class="border-radius-10">
											<img src="<?php base_url();?>assets/imgs/shop/pr3.jpg" alt="product image" />
										</figure>
										<figure class="border-radius-10">
											<img src="<?php base_url();?>assets/imgs/shop/pr4.jpg" alt="product image" />
										</figure>
										<figure class="border-radius-10">
											<img src="<?php base_url();?>assets/imgs/shop/pr5.jpg" alt="product image" />
										</figure>
										<figure class="border-radius-10">
											<img src="<?php base_url();?>assets/imgs/shop/pr6.jpg" alt="product image" />
										</figure>
										<figure class="border-radius-10">
											<img src="<?php base_url();?>assets/imgs/shop/pr7.jpg" alt="product image" />
										</figure>
									</div>
									<!-- THUMBNAILS -->
									<div class="slider-nav-thumbnails">
										<div><img src="<?php base_url();?>assets/imgs/shop/pr3.jpeg" alt="product image" /></div>
										<div><img src="<?php base_url();?>assets/imgs/shop/pr4.jpeg" alt="product image" /></div>
										<div><img src="<?php base_url();?>assets/imgs/shop/pr5.jpeg" alt="product image" /></div>
										<div><img src="<?php base_url();?>assets/imgs/shop/pr6.jpeg" alt="product image" /></div>
										<div><img src="<?php base_url();?>assets/imgs/shop/pr7.jpeg" alt="product image" /></div>
										<div><img src="<?php base_url();?>assets/imgs/shop/pr8.jpeg" alt="product image" /></div>
										<div><img src="<?php base_url();?>assets/imgs/shop/pr9.jpeg" alt="product image" /></div>
									</div>
								</div>
								<!-- End Gallery -->
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="detail-info pr-30 pl-30">
									<span class="stock-status out-stock">Venta de descuento</span>
									<h3 class="title-detail"><a href="#" class="text-heading">Para los hombres</a></h3>
									<div class="product-detail-rating">
										<div class="product-rate-cover text-end">
											<div class="product-rate d-inline-block">
												<div class="product-rating" style="width: 90%"></div>
											</div>
											<span class="font-small ml-5 text-muted"> (32 críticas)</span>
										</div>
									</div>
									<div class="clearfix product-price-cover">
										<div class="product-price primary-color float-left">
											<span class="current-price text-brand">Bs 40</span>
											<span>
												<span class="save-price font-md color3 ml-15">20% Descuento</span>
												<span class="old-price font-md ml-15">Bs 50</span>
											</span>
										</div>
									</div>
									<div class="detail-extralink mb-30">
										<div class="detail-qty border radius">
											<a href="#" class="qty-down"><i class="fi-rs-angle-small-down"></i></a>
											<span class="qty-val">1</span>
											<a href="#" class="qty-up"><i class="fi-rs-angle-small-up"></i></a>
										</div>
										<div class="product-extra-link2">
											<button type="submit" class="button button-add-to-cart"><i class="fi-rs-shopping-cart"></i>Añadir a la cesta</button>
										</div>
									</div>
								</div>
								<!-- Detail Info -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<div id="preloader-active">
				<div class="preloader d-flex align-items-center justify-content-center">
					<div class="preloader-inner position-relative">
						<div class="text-center">
							<img src="<?php base_url();?>assets/imgs/theme/perfum.gif" alt="" />
						</div>
					</div>
				</div>
			</div>
<header class="header-area header-style-1 header-height-2">
			<div class="header-middle header-middle-ptb-1 d-none d-lg-block">
				<div class="container">
					<div class="header-wrap">
						<div class="logo logo-width-1">
							<a href="<?php echo base_url ('/');?>"><img src="<?php base_url();?>assets/imgs/theme/2.png" alt="logo" /></a>
						</div>
						<div class="header-right">
							<div class="search-style-2">
								<form action="#">
									<select class="select-active">
										<option>Todas las categorias</option>
										<option>VICTORIA SECRET</option>
										<option>STREET LOOKS</option>
										<option>CHARM</option>
										<option>MIRAGE</option>
									</select>
									<input type="text" placeholder="Buscar artículos..." />
								</form>
							</div>
							<div class="header-action-right">
								<div class="header-action-2">
									<div class="search-location">
										<form action="#">
											<select class="select-active">
												<option>Todas las categorias</option>
												<option>Santa Cruz</option>
												<option>La paz</option>
												<option>Chuquisaca</option>
												<option>Potosi</option>
												<option>Pando</option>
												<option>Beni</option>
												<option>Cochabamba</option>
												<option>Tarija</option>
												<option>Oruro</option>
											</select>
										</form>
									</div>
									<div class="header-action-icon-2">
									<? if ($this->session->userdata('in_usuario_hotys')): ?>
										<a href="<?php echo base_url ('micuenta');?>">
									<? endif; ?>
									<? if (!$this->session->userdata('in_usuario_hotys')): ?>
										<a href="<?php echo base_url ('login');?>">
									<? endif; ?>
									<img class="svgInject" alt="Nest" src="<?php base_url();?>assets/imgs/theme/icons/icon-user.svg" />
										</a>
										<span class="lable ml-0">Mi Cuenta</span>
									</div>
									<div class="header-action-icon-2">
										<a href="<?php echo base_url ('milistadeseos');?>">
											<img class="svgInject" alt="Nest" src="<?php base_url();?>assets/imgs/theme/icons/icon-heart.svg" />
										</a>
										<span class="lable">Lista de deseos</span>
									</div>
									<div class="header-action-icon-2">
										<a class="mini-cart-icon" href="<?php echo base_url ('micarrito');?>">
											<img alt="Nest" src="<?php base_url();?>assets/imgs/theme/icons/icon-cart.svg" />
										</a>
										<span class="lable">Carro</span>
										<div class="cart-dropdown-wrap cart-dropdown-hm2">
											<ul>
												<li>
													<div class="shopping-cart-img">
														<a href="<?php echo base_url ('micarrito');?>"><img alt="Nest" src="<?php base_url();?>assets/imgs/shop/pr3.jpg" /></a>
													</div>
													<div class="shopping-cart-title">
														<h4><a href="#">G FOR WOMEN "SEXY"</a></h4>
														<h4><span>1 × </span>Bs 60</h4>
													</div>
													<div class="shopping-cart-delete">
														<a href="#"><i class="fi-rs-cross-small"></i></a>
													</div>
												</li>
												<li>
													<div class="shopping-cart-img">
														<a href="<?php echo base_url ('micarrito');?>"><img alt="Nest" src="<?php base_url();?>assets/imgs/shop/pr2.jpg" /></a>
													</div>
													<div class="shopping-cart-title">
														<h4><a href="#">VICTORIA SECRET</a></h4>
														<h4><span>1 × </span>Bs 70</h4>
													</div>
													<div class="shopping-cart-delete">
														<a href="#"><i class="fi-rs-cross-small"></i></a>
													</div>
												</li>
											</ul>
											<div class="shopping-cart-footer">
												<div class="shopping-cart-total">
													<h4>Total <span>Bs 130</span></h4>
												</div>
												<div class="shopping-cart-button">
													<a href="carrito" class="outline">Ver carrito</a>
													<a href="#">Verificar</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="header-bottom header-bottom-bg-color sticky-bar">
				<div class="container">
					<div class="header-wrap header-space-between position-relative">
						<div class="logo logo-width-1 d-block d-lg-none">
							<a href="home"><img src="<?php base_url();?>assets/imgs/theme/2.png" alt="logo" /></a>
						</div>
						<div class="header-nav d-none d-lg-flex">
							<div class="main-categori-wrap d-none d-lg-block">
								<a class="categories-button-active" href="#">
									<span class="fi-rs-apps"></span>todas las categorias
									<i class="fi-rs-angle-down"></i>
								</a>
								<div class="categories-dropdown-wrap categories-dropdown-active-large font-heading">
									<div class="d-flex categori-dropdown-inner">
										<ul>
											<li>
												<a href="#"> <img src="<?php base_url();?>assets/imgs/theme/icons/vs.png" alt="" />VICTORIA SECRET</a>
											</li>
											<li>
												<a href="#"> <img src="<?php base_url();?>assets/imgs/theme/icons/st.jpeg" alt="" />STREET LOOKS</a>
											</li>
											<li>
												<a href="#"> <img src="<?php base_url();?>assets/imgs/theme/icons/charm.jpeg" alt="" />CHARM</a>
											</li>
											<li>
												<a href="#"> <img src="<?php base_url();?>assets/imgs/theme/icons/m.jfif" alt="" />MIRAGE</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="main-menu main-menu-padding-1 main-menu-lh-2 d-none d-lg-block font-heading">
								<nav>
									<ul>
										<li class="hot-deals"><img src="<?php base_url();?>assets/imgs/theme/icons/icon-hot.svg" alt="hot deals" /><a href="#">Las mejores ofertas</a></li>
										<li>
											<a class="active" href="<?php echo base_url ('/');?>">Hogar <i></i></a>
										</li>
										<li>
											<a href="#">Tienda <i class="fi-rs-angle-down"></i></a>
											<ul class="sub-menu">
												<li><a href="<?php echo base_url ('micarrito');?>">Carrito de compras</a></li>
												<li><a href="#">Tienda de pago</a></li>
											</ul>
										</li>
										<li>
											<a href="#">Paginas<i class="fi-rs-angle-down"></i></a>
											<ul class="sub-menu">
												<li><a href="#">Sobre nosotros</a></li>
												<li><a href="micuenta">Mi cuenta</a></li>
												<li><a href="login">Acceso</a></li>
												<li><a href="signin">Registrarse</a></li>
												<li><a href="#">Guía de compra</a></li>
											</ul>
										</li>
										<li>
											<a href="<?php echo base_url ('contacto');?>">Contacto</a>
										</li>
									</ul>
								</nav>
							</div>
						</div>
						<div class="hotline d-none d-lg-flex">
							<img src="<?php base_url();?>assets/imgs/theme/icons/icon-headphone.svg" alt="hotline" />
							<p>+591 70791044<span>Horario de atencion de Lunes-Domingo de 8:00 a.m. - 17:00 p.m.</span></p>
						</div>
						<div class="header-action-icon-2 d-block d-lg-none">
							<div class="burger-icon burger-icon-white">
								<span class="burger-icon-top"></span>
								<span class="burger-icon-mid"></span>
								<span class="burger-icon-bottom"></span>
							</div>
						</div>
						<div class="header-action-right d-block d-lg-none">
							<div class="header-action-2">
								<div class="header-action-icon-2">
									<a href="<?php echo base_url ('milistadeseos');?>">
										<img alt="Nest" src="<?php base_url();?>assets/imgs/theme/icons/icon-heart.svg" />
										<span class="pro-count white"></span>
									</a>
								</div>
								<div class="header-action-icon-2">
									<a class="mini-cart-icon" href="<?php echo base_url ('micarrito');?>">
										<img alt="Nest" src="<?php base_url();?>assets/imgs/theme/icons/icon-cart.svg" />
										<span class="pro-count white"></span>
									</a>
									<div class="cart-dropdown-wrap cart-dropdown-hm2">
										<ul>
											<li>
												 <div class="shopping-cart-img">
                                                        <a href="#"><img alt="Nest" src="<?php base_url();?>assets/imgs/shop/pr3.jpeg" /></a>
                                                    </div>
                                                    <div class="shopping-cart-title">
                                                        <h4><a href="shopproduct-right">G FOR WOMEN "SEXY"</a></h4>
                                                        <h4><span>1 × </span>Bs 60</h4>
                                                    </div>
                                                    <div class="shopping-cart-delete">
                                                        <a href="#"><i class="fi-rs-cross-small"></i></a>
                                                    </div>
                                                </li>
                                                <li>
                                                   <div class="shopping-cart-img">
                                                        <a href="#"><img alt="Nest" src="<?php base_url();?>assets/imgs/shop/pr4.jpeg" /></a>
                                                    </div>
                                                    <div class="shopping-cart-title">
                                                        <h4><a href="#">STILETTO</a></h4>
                                                        <h4><span>1 × </span>Bs 70</h4>
                                                    </div>
                                                    <div class="shopping-cart-delete">
                                                        <a href="#"><i class="fi-rs-cross-small"></i></a>
                                                    </div>
                                                </li>
                                            </ul>
                                            <div class="shopping-cart-footer">
                                                <div class="shopping-cart-total">
                                                    <h4>Total <span>Bs 130</span></h4>
                                                </div>
											<div class="shopping-cart-button">
												<a href="<a href="<?php echo base_url ('micarrito');?>">Ver carrito</a>
												<a href="#">Verificar</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<div class="mobile-header-active mobile-header-wrapper-style">
			<div class="mobile-header-wrapper-inner">
				<div class="mobile-header-top">
					<div class="mobile-header-logo">
						<a href="home"><img src="<?php base_url();?>assets/imgs/theme/2.png" alt="logo" /></a>
					</div>
					<div class="mobile-menu-close close-style-wrap close-style-position-inherit">
						<button class="close-style search-close">
							<i class="icon-top"></i>
							<i class="icon-bottom"></i>
						</button>
					</div>
				</div>
				<div class="mobile-header-content-area">
					<div class="mobile-search search-style-3 mobile-header-border">
						<form action="#">
							<input type="text" placeholder="Buscar artículos…" />
							<button type="submit"><i class="fi-rs-search"></i></button>
						</form>
					</div>
					<div class="mobile-menu-wrap mobile-header-border">
						<!-- mobile menu start -->
						<nav>
                            <ul class="mobile-menu font-heading">
                                <li class="menu-item-has-children">
                                    <a href="home">Hogar</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Tienda</a>
                                    <ul class="dropdown">                    
                                        <li><a href="<a href="<?php echo base_url ('micarrito');?>">Carrito de compras</a></li>
                                        <li><a href="#">Tienda de pago</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Pagina</a>
                                    <ul class="dropdown">
                                        <li><a href="#">Sobre nosotros</a></li>
                                        <li><a href="<?php echo base_url ('micuenta');?>">Mi cuenta</a></li>
                                        <li><a href="<?php echo base_url ('login');?>">Acceso</a></li>
                                        <li><a href="<?php echo base_url ('signin');?>">Registrarse</a></li>
                                        <li><a href="#">Guía de Compra</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
						<!-- mobile menu end -->
					</div>
					<div class="mobile-header-info-wrap">
						<div class="single-mobile-header-info">
							<a href="pagecontact"><i class="fi-rs-marker"></i> Nuestra ubicación </a>
						</div>
						<div class="single-mobile-header-info">
							<a href="pagelogin"><i class="fi-rs-user"></i>Iniciar sesión</a>
						</div>
						<div class="single-mobile-header-info">
							<a href="#"><i class="fi-rs-headphones"></i>(+591) - 70791044 </a>
						</div>
					</div>
					<div class="mobile-social-icon mb-50">
						<h6 class="mb-15">Síguenos</h6>
						<a href="#"><img src="<?php base_url();?>assets/imgs/theme/icons/icon-facebook-white.svg" alt="" /></a>
					</div>
				</div>
			</div>
		</div>