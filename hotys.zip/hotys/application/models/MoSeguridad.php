<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MoSeguridad extends CI_Model {

        public function sesion_usuario($id)
        {
          $this->db->select('a.*,
                             b.tx_nb_rol');
                   $this->db->from('i001t_usuario as a');
                   $this->db->join('i002t_rol as b', 'a.nu_rol_id=b.id');
                   $this->db->where('a.id',$id);
                   $this->db->where('a.in_activo','1');
                   $consulta = $this->db->get();
            if($consulta->num_rows() == 1)
            {
            return $consulta->row();
            }
            else
            {
            return false;
            }
        }

  /*      public function menu_usuario($co_usuario)
        {
          $this->db->select('a.tx_menu');
                   $this->db->from('i008t_menu_usuario as a');
                   $this->db->join('i007t_tipo_usuario as b', 'a.co_tipo_usuario=b.co_tipo_usuario');
                   $this->db->join('i002t_usuario as c', 'c.co_tipo_usuario=b.co_tipo_usuario');
                   $this->db->where('c.co_usuario',$co_usuario);
                //   $this->db->where('a.in_activo',1);
                   $consulta = $this->db->get();
            if($consulta->num_rows() == 1)
            {
            return $consulta->row();
            }
            else
            {
            return false;
            }
        }*/
        }
