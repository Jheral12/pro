<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MoProducto extends CI_Model {

        public function lstall_producto()
        {
            $this->db->select('a.*,b.tx_nb_categoria');
            $this->db->from('i003t_producto as a');
            $this->db->join('i004t_categoria as b', 'a.nu_categoria_producto_id=b.id');
            $this->db->order_by("a.fe_add_producto", "desc");
            $consulta = $this->db->get();
            if ($consulta)
            {
                return $consulta->result();
            }
            else
            {
                return false;
            }
        }

        public function lstall_producto_categoria($id,$limit)
        {
            $this->db->select('a.*,b.tx_nb_categoria');
            $this->db->from('i003t_producto as a');
            $this->db->join('i004t_categoria as b', 'a.nu_categoria_producto_id=b.id');
            $this->db->order_by("a.nu_orden_producto", "asc");
            $this->db->where('a.nu_categoria_producto_id', $id);
            $this->db->limit($limit);
            $consulta = $this->db->get();
            if ($consulta)
            {
                return $consulta->result();
            }
            else
            {
                return false;
            }
        }

        public function add()
        {
            $data = array(
              'tx_titulo_producto'	        =>strtolower($this->input->post('descripcion')),
              'nu_categoria_producto_id'	=>strtolower($this->input->post('categoria')),
              'tx_slug_producto'	        =>strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $this->input->post('descripcion')))),
              'tx_url_foto_producto '		=>trim(strtolower($this->input->post('foto'))),
              'nu_precio_producto'		    =>$this->input->post('precio'),
              'nu_usuario_add_id '	        =>$this->session->userdata('id_usuario'),
              'nu_usuario_upd_id'           =>$this->session->userdata('id_usuario'));
            $consulta=$this->db->insert('i003t_producto', $data);
            if ($consulta==true) {
                return true;
            } else {
                return false;
            }
        }

        public function upd()
        {

           $data=array(
              'tx_titulo_producto'	        =>strtolower($this->input->post('descripcion')),
              'nu_categoria_producto_id'	=>strtolower($this->input->post('categoria')),
              'tx_slug_producto'	        =>strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $this->input->post('descripcion')))),
              'tx_url_foto_producto '		=>trim(strtolower($this->input->post('foto'))),
              'nu_precio_producto'		    =>$this->input->post('precio'),
              'nu_usuario_add_id '	        =>$this->session->userdata('id_usuario'),
              'nu_usuario_upd_id'           =>$this->session->userdata('id_usuario'));
               $this->db->where('id',$this->input->post('id'));
                $consulta=$this->db->update('i003t_producto', $data);
                if ($consulta)
                { return true;}
                else
                { return false;}
        }

        public function findbyid()
        {
          $this->db->where('id',$this->input->post('id'));
          $consulta = $this->db->get('i003t_producto');
            if ($consulta->num_rows() > 0) {
                return true;
            } else {
                return false;
            }
        }

        public function del()
        {
            $this->db->where('id', $this->input->post('id'));
            $query=$this->db->delete('i003t_producto');
            if ($query) {
                return true;
            } else {
                return false;
            }
        }


        }
