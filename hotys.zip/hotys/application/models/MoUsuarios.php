<?php
class MoUsuarios extends CI_Model {

        public function filas()
        {
          $consulta = $this->db->get('i001t_usuario');
          return  $consulta->num_rows();
        }

        public function lstall()
        {
          $this->db->select('a.tx_nombres,
                            a.tx_apellidos,
                            a.tx_correo,
                            a.tx_telefono,
                            a.id_usuario,
                            a.in_status,
                            a.url_avatar,
                            a.fe_add,
                            a.fe_upd,
                            a.id_usuario_rol');
          $this->db->from('i001t_usuario as a');
          $this->db->join('i001t_usuario as b', 'a.id_usuario_add=b.id_usuario');
          //$this->db->join('i004t_roles as c', 'a.id_usuario_rol=c.co_rol');
          //$this->db->join('i005t_titles as d', 'a.id_usuario_title=d.co_title');
          $this->db->order_by("b.fe_add", "desc");
          $consulta = $this->db->get();
            if ($consulta)
            {
              return $consulta->result();
            }
            else
            {
              return false;
            }
        }

        public function list_user_active()
        {
          $this->db->select('a.tx_first_name,
                            a.tx_last_name,
                            a.id_usuario');
          $this->db->from('i001t_usuario as a');
          $this->db->where('in_status','1');
          $this->db->order_by("a.tx_first_name", "desc");
          $consulta = $this->db->get();
            if ($consulta)
            {
              return $consulta->result();
            }
            else
            {
              return false;
            }
        }

        public function add()
        {
            $data = array(
              'tx_usuario'	        =>strtolower($this->input->post('username')),
              'tx_correo'	          =>strtolower($this->input->post('email')),
              'tx_clave'		        =>md5($this->input->post('password')));
            $consulta=$this->db->insert('i001t_usuario', $data);
            if ($consulta==true) {
                return true;
            } else {
                return false;
            }
        }

        public function edit($nb_foto)
        {

          if ($nb_foto==null) {
            $data=array(
              'tx_first_name'	 =>ucwords(strtolower($this->input->post('tx_first_name'))),
              'tx_last_name'	 =>ucwords(strtolower($this->input->post('tx_last_name'))),
              'tx_correo'		   =>strtolower($this->input->post('tx_correo')),
              'id_usuario_rol'		 =>$this->input->post('id_usuario_rol'),
              'id_usuario_title'	 =>$this->input->post('id_usuario_title'),
              'in_status'			 =>$this->input->post('in_status'),
              'id_usuario_upd'    =>$this->session->userdata('co_usuario'));
          }
          else {
            $data=array(
              'tx_first_name'	 =>ucwords(strtolower($this->input->post('tx_first_name'))),
              'tx_last_name'	 =>ucwords(strtolower($this->input->post('tx_last_name'))),
              'tx_correo'		   =>strtolower($this->input->post('tx_correo')),
              'id_usuario_rol'		 =>$this->input->post('id_usuario_rol'),
              'id_usuario_title'	 =>$this->input->post('id_usuario_title'),
              'in_status'			 =>$this->input->post('in_status'),
              'url_avatar'		 =>$nb_foto,
              'id_usuario_upd'    =>$this->session->userdata('co_usuario'));
            }
                $this->db->where('id_usuario',$this->input->post('id_usuario'));
                $consulta=$this->db->update('i001t_usuario', $data);
                if ($consulta)
                { return true;}
                else
                { return false;}
        }

        public function repassword($id)
        {
            $data=array(
              'tx_clave' =>md5("prr2021"),
              'id_usuario_upd'	=>$this->session->userdata('co_usuario'));
              $this->db->where('id_usuario', $id);
                $consulta=$this->db->update('i001t_usuario', $data);
                if ($consulta)
                { return true;}
                else
                { return false;}
        }

        public function findbyid()
        {
          $this->db->where('id_usuario',$this->input->post('id_usuario'));
          $query = $this->db->get('i001t_usuario');
            if ($query->num_rows() > 0) {
                return true;
            } else {
                return false;
            }
        }

        public function findbyidemail()
        {
          $this->db->where('id_usuario !=',$this->input->post('id_usuario'));
          $this->db->where('tx_correo',strtolower($this->input->post('tx_correo')));
          $query = $this->db->get('i001t_usuario');
            if ($query->num_rows() > 0) {
                return true;
            } else {
                return false;
            }
        }

        public function find_username()
        {
          $this->db->where('tx_usuario',strtolower($this->input->post('username')));
          $query = $this->db->get('i001t_usuario');
            if ($query->num_rows() > 0) {
                return true;
            } else {
                return false;
            }
        }

        public function find_email()
        {
          $this->db->where('tx_correo',strtolower($this->input->post('email')));
          $query = $this->db->get('i001t_usuario');
            if ($query->num_rows() > 0) {
                return true;
            } else {
                return false;
            }
        }

        public function findbyemail()
        {
          $this->db->where('id_usuario',$this->input->post('tx_correo'));
          $query = $this->db->get('i001t_usuario');
            if ($query->num_rows() == 1) {
                return true;
            } else {
                return false;
            }
        }

        public function valida_usuario($tx_correo,$tx_clave)
        {
          $this->db->select('tx_clave,
                             tx_correo,
                             id');
          $this->db->from('i001t_usuario');
          $this->db->where('tx_correo', $tx_correo);
          $this->db->where('tx_clave', $tx_clave);
          $consulta = $this->db->get();
          if ($consulta->num_rows() > 0){return $consulta->row();}
            else{return false;}
        }

        public function indicador_usuario($tx_correo)
        {
          $this->db->select('tx_correo');
          $this->db->from('i001t_usuario');
          $this->db->where('tx_correo', $tx_correo);
          $consulta = $this->db->get();
          if ($consulta->num_rows() > 0){return true;}
            else  {return false;}
        }

        public function usuario_activo($tx_correo,$tx_clave)
        {
          $this->db->select('tx_clave,
                             tx_correo');
          $this->db->from('i001t_usuario');
          $this->db->where('tx_clave', $tx_clave);
          $this->db->where('tx_correo', $tx_correo);
          $this->db->where('in_activo','1');
          $consulta = $this->db->get();
          if ($consulta->num_rows() > 0){
            return true;
            }
            else
            {
            return false;
            }
        }

        public function usuarioeliminado($tx_correo,$tx_clave)
        {
          $this->db->select('tx_clave,
                             tx_correo');
          $this->db->from('i001t_usuario');
          $this->db->where('tx_clave', $tx_clave);
          $this->db->where('tx_correo', $tx_correo);
          $this->db->where('in_status','2');
          $consulta = $this->db->get();
          if ($consulta->num_rows() > 0){
            return true;
            }
            else
            {
            return false;
            }
        }

        public function active($id)
        {
            $data=array(
              'in_status'			  =>'1',
              'id_usuario_upd'	    =>$this->session->userdata('co_usuario'));
               $this->db->where('id_usuario', $id);
                $consulta=$this->db->update('i001t_usuario', $data);
                if ($consulta)
                { return true;}
                else
                { return false;}
        }

        public function inactive($id)
        {
            $data=array(
              'in_status'			  =>'0',
              'id_usuario_upd'	    =>$this->session->userdata('co_usuario'));
                $this->db->where('id_usuario', $id);
                $consulta=$this->db->update('i001t_usuario', $data);
                if ($consulta)
                { return true;}
                else
                { return false;}
        }

        public function deltemporarily($id)
        {
            $data=array(
              'in_status'			  =>'2',
              'id_usuario_upd'	    =>$this->session->userdata('co_usuario'));
                $this->db->where('id_usuario', $id);
                $consulta=$this->db->update('i001t_usuario', $data);
                if ($consulta)
                { return true;}
                else
                { return false;}
        }

        public function del($id)
        {
            $this->db->where('id_usuario', $id);
            $query=$this->db->delete('i001t_usuario');
            if ($query) {
                return true;
            } else {
                return false;
            }
        }

        public function changepassword($id,$tx_clave_nueva)
        {
            $data=array('tx_clave'	=>$tx_clave_nueva);
            if ($id==null) {
                return false;
            } else {
                $this->db->where('id_usuario', $id);
                return $this->db->update('i001t_usuario', $data);
            }
        }

        }
