<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CoCuenta extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model("MoUsuarios");
		$this->load->model("MoProducto");
		if(!$this->session->userdata('in_usuario_hotys')){redirect('salir');}
	}

	public function micuenta()
	{
		$datos['css']=array(
			//	'web/AdminLTE-3.1.0/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css',
			//	'web/AdminLTE-3.1.0/plugins/datatables-buttons/css/buttons.bootstrap4.min.css'
			   );    
			   
		$datos['js']=array(
				 'assets/js/plugins/jquery-validation/jquery.validate.min.js',
			//	 'assets/js/IuLogon.js'
			   );
		$this->load->view('ViCabeceraPagina',$datos);
		$this->load->view('CaCuenta/ViMiCuenta');
		$this->load->view('ViPiePagina');		

	}

	public function micarrito()
	{
		$datos['css']=array(
			//	'web/AdminLTE-3.1.0/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css',
			//	'web/AdminLTE-3.1.0/plugins/datatables-buttons/css/buttons.bootstrap4.min.css'
			   );    
			   
		$datos['js']=array(
				 'assets/js/plugins/jquery-validation/jquery.validate.min.js',
			//	 'assets/js/IuLogon.js'
			   );
		$this->load->view('ViCabeceraPagina',$datos);
		$this->load->view('CaCuenta/ViMiCarrito');
		$this->load->view('ViPiePagina');		

	}

	public function milistadeseos()
	{
		$datos['css']=array(
			//	'web/AdminLTE-3.1.0/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css',
			//	'web/AdminLTE-3.1.0/plugins/datatables-buttons/css/buttons.bootstrap4.min.css'
			   );    
			   
		$datos['js']=array(
				 'assets/js/plugins/jquery-validation/jquery.validate.min.js',
			//	 'assets/js/IuLogon.js'
			   );
		$this->load->view('ViCabeceraPagina',$datos);
		$this->load->view('CaCuenta/ViMiListaDeseos');
		$this->load->view('ViPiePagina');		

	}

	public function administrar()
	{
		if (($this->session->userdata("co_tipo_usuario")!=1) ){show_404();}

		$datos['css']=array(
			//	'web/AdminLTE-3.1.0/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css',
			//	'web/AdminLTE-3.1.0/plugins/datatables-buttons/css/buttons.bootstrap4.min.css'
			   );    
			   
		$datos['js']=array(
				 'assets/js/plugins/jquery-validation/jquery.validate.min.js',
				 'assets/js/IuCrudProducto.js'
			   );
		$datos["lstall_producto"]	=$this->MoProducto->lstall_producto();
		$this->load->view('ViCabeceraPagina', $datos);	   
		$this->load->view('CaAdmin/ViAdministrar');
		$this->load->view('ViPiePagina');		

	}

	

	public function respuesta($estado,$mensaje)
	{
		if (!isset($respuesta)) {
			$respuesta = (object)array();}
			$respuesta->resultado = $estado;
			$respuesta->mensaje   = $mensaje;
			return $respuesta;
	}
}
