<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Clase CoProducto.
 * Funciones: 1.
 * __construct.
 */

class CoProducto extends CI_Controller
{

    /**
     * Constructor de la clase.
     * Conecta la con el modelo MoProducto.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model("MoProducto");
      if(!$this->session->userdata('in_usuario_hotys')){redirect('salir');}
      else{if (($this->session->userdata("co_tipo_usuario")!=1)){show_404();}}

    }

    public function save()
    {
      if  (empty($this->input->post('id'))){
        $add =$this->MoProducto->add();
        if ($add) {
        $estado = True;
        $mensaje = 'Guardado!';
        } else {
        $estado = False;
        $mensaje = 'No Guardado!';
        }
      }
      else
      {
       /* $this->form_validation->set_rules('id', 'id', 'required|min_length[1]|max_length[20]');  
        $this->form_validation->set_rules('nu_rut', 'RUT', 'required|min_length[1]|max_length[20]');
        $this->form_validation->set_rules('tx_nombre', 'Nombre', 'required|min_length[1]|max_length[60]');
        $this->form_validation->set_rules('tx_apellido', 'Apellido', 'required|min_length[1]|max_length[100]');
        $this->form_validation->set_rules('tx_correo', 'Correo', 'required|min_length[1]|max_length[100]');
        $this->form_validation->set_rules('co_usuario_rol', 'Rol', 'required');
        $this->form_validation->set_rules('in_status', 'Activo', 'required');
        if ($this->form_validation->run() == false) {
        $estado = False;
        $mensaje = 'Datos Requeridos!';
        } 
        else 
        {*/
          $upd =$this->MoProducto->upd();
          if ($upd) {
          $estado = True;
          $mensaje = 'Guardado!';
          } else {
          $estado = False;
          $mensaje = 'No pudo ser editado!';
          }
        
      }
    echo json_encode($this->respuesta($estado,$mensaje));
    }

    public function del($id)
    {
    if (is_numeric($id)) {
    $findid = $this->MoProducto->findbyid();
    if ($findid==false) {
    $estado = False;
    $mensaje = 'Producto no encontrado!';
    } else {
    $del = $this->MoProducto->del();
    if ($del) {
    $estado = true;
    $mensaje = 'Borrado!';
    } else {
    $estado = false;
    $mensaje = 'Producto no puede ser borrado!';
    }
    }
    }
    else {
    $estado = false;
    $mensaje = 'Parametro incorrecto!';
    }
    echo json_encode($this->respuesta($estado,$mensaje));
    }

    public function respuesta($estado,$mensaje)
    {
    if (!isset($respuesta)) {
    $respuesta = (object)array();}
    $respuesta->resultado = $estado;
    $respuesta->mensaje   = $mensaje;
    return $respuesta;
    }

}
