<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Clase CoSeguridad.
 * Conecta la con el modelo MoSeguridad.
 * Funciones: 1.
 * __construct.
 */

class CoSeguridad extends CI_Controller
{

    /**
     * Constructor de la clase.
     * Conecta la con el modelo MoSeguridad
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model("MoUsuarios");
        $this->load->model("MoSeguridad");
        if(!$this->session->userdata('in_usuario_hotys')){redirect('salir');}

    }

    public function sesion()
    {
      $id_usuario			    =$this->session->userdata('id_usuario');
      $sesion_usuario 	  =$this->MoSeguridad->sesion_usuario($id_usuario);
      if($sesion_usuario)
      {
        $data = array(
        'tx_usuario' 		  => $sesion_usuario->tx_usuario,
        'co_tipo_usuario' => $sesion_usuario->nu_rol_id,
        'nb_rol_usuario'  => $sesion_usuario->tx_nb_rol);
        $this->session->set_userdata($data);
        redirect('micuenta');
      }
      else
      {
        redirect('salir');
      }
    }

    public function changepassword()
    {
      $this->form_validation->set_rules('tx_clave', 'Contrasena Actual', 'required|min_length[5]|max_length[20]');
      $this->form_validation->set_rules('tx_clave_nueva', 'Nueva Contrasena', 'required|min_length[5]|max_length[20]');
      $this->form_validation->set_rules('tx_clave_nueva_repetida', 'Nueva Contrasena Repetida', 'required|min_length[5]|max_length[20]');
      if($this->form_validation->run() == false)
      {
        $estado = False;
        $mensaje = 'Data required!';
      }
      else
      {
        $nu_doc				      = $this->session->userdata('nu_doc');
        $tx_clave			      = md5($this->input->post('tx_clave'));
        $valida_usuario			= $this->MoUsers->valida_usuario($nu_doc,$tx_clave);
        if ($valida_usuario == False) {
          $estado = False;
          $mensaje = 'Wrong username or password!';
        }
        else
        {
          $co_usuario					= $this->session->userdata('co_usuario');
          $tx_clave_nueva	    = md5($this->input->post('tx_clave_nueva'));
          $cambiar_clave			= $this->MoUsers->changepassword($co_usuario,$tx_clave_nueva);
          if ($cambiar_clave) {
            $estado = True;
            $mensaje = 'Change Password Done!';
          }
          else {
            $estado = True;
            $mensaje = 'No password update!';
          }
        }
      }
     echo json_encode($this->respuesta($estado,$mensaje));
    }

    public function respuesta($estado,$mensaje)
    {
    if (!isset($respuesta)) {
    $respuesta = (object)array();}
    $respuesta->resultado = $estado;
    $respuesta->mensaje   = $mensaje;
    return $respuesta;
    }
}
