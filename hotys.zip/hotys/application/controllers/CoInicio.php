<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CoInicio extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model("MoUsuarios");
		$this->load->model("MoProducto");
	}

	public function index()
	{
		$datos["lstall_producto_categoria_m1"]	=$this->MoProducto->lstall_producto_categoria(1,10);
		$datos["lstall_producto_categoria_m2"]	=$this->MoProducto->lstall_producto_categoria(2,10);
		$this->load->view('ViCabeceraPagina', $datos);	   
		$this->load->view('ViVitrina');
		$this->load->view('ViPiePagina');
	}

	public function login()
	{
		if($this->session->userdata('in_usuario_hotys')){redirect('micuenta');}
		$datos['tx_token'] 	= $this->token();
		$datos['css']=array(
			//	'web/AdminLTE-3.1.0/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css',
			//	'web/AdminLTE-3.1.0/plugins/datatables-buttons/css/buttons.bootstrap4.min.css'
			   );    
			   
		$datos['js']=array(
				 'assets/js/plugins/jquery-validation/jquery.validate.min.js',
				 'assets/js/IuLogon.js'
			   );
		$this->load->view('ViCabeceraPagina',$datos);
		$this->load->view('CaCuenta/ViLogin');
		$this->load->view('ViPiePagina');		

	}

	public function signin()
	{
		if($this->session->userdata('in_usuario_hotys')){redirect('micuenta');}
		$datos['tx_token'] 	= $this->token();
		$datos['css']=array(
			//	'web/AdminLTE-3.1.0/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css',
			//	'web/AdminLTE-3.1.0/plugins/datatables-buttons/css/buttons.bootstrap4.min.css'
			   );    
			   
		$datos['js']=array(
				 'assets/js/plugins/jquery-validation/jquery.validate.min.js',
				 'assets/js/IuSignin.js'
			   );
		$this->load->view('ViCabeceraPagina',$datos);
		$this->load->view('CaCuenta/ViRegistro');
		$this->load->view('ViPiePagina');		

	}

	public function contacto()
	{
		$datos['css']=array(
			//	'web/AdminLTE-3.1.0/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css',
			//	'web/AdminLTE-3.1.0/plugins/datatables-buttons/css/buttons.bootstrap4.min.css'
			   );    
			   
		$datos['js']=array(
				 'assets/js/plugins/jquery-validation/jquery.validate.min.js',
			//	 'assets/js/IuLogon.js'
			   );
		$this->load->view('ViCabeceraPagina',$datos);
		$this->load->view('ViContacto');
		$this->load->view('ViPiePagina');		

	}

	public function registro()
	{

		if($this->input->post('tx_token') && $this->input->post('tx_token') == $this->session->userdata('tx_token'))
		{
			$this->form_validation->set_rules('email', 'correo', 'required|trim|min_length[2]|max_length[150]');
			$this->form_validation->set_rules('username', 	'username', 'required|trim|min_length[1]|max_length[150]');
			$this->form_validation->set_rules('password', 'clave', 'required|min_length[4]|max_length[150]');
			if($this->form_validation->run() == false)
			{
				
				$estado = False;
				$mensaje = '¡Datos Requeridos!';
			}
			else
			{
				if($this->input->post('tx_token') == $this->session->userdata('tx_token')) 
			{ 
				$find_email			    = $this->MoUsuarios->find_email();
				$find_username			= $this->MoUsuarios->find_username();

				if($find_username)
				{
					$estado = False;
					$mensaje = '¡Usuario no disponible!';
				}
				else
				{
					if($find_email)
					{
						$estado = False;
						$mensaje = '¡Correo no disponible!';
					}
					else
					{
						$add = $this->MoUsuarios->add();
						if($add)
						{
							$estado = True;
							$mensaje = '¡Registro exitoso!';
						}
						else
						{
							$estado = False;
							$mensaje = '¡No pudo ser registrado, por favor reintente!';
						}
					}
				}

			}
			else
			{
				$estado = False;
				$mensaje = 'Token vencido!';
			}
			}
		}
		else
		{
			$estado = False;
			$mensaje = 'Token Requerido!';
		}
		  echo json_encode($this->respuesta($estado,$mensaje));
	}

	public function ingreso()
	{

		if($this->input->post('tx_token') && $this->input->post('tx_token') == $this->session->userdata('tx_token'))
		{
						$this->form_validation->set_rules('emailIngreso', 'correo', 'required|trim|min_length[2]|max_length[150]');
						$this->form_validation->set_rules('passwordIngreso', 'clave', 'required|min_length[4]|max_length[150]');
						if($this->form_validation->run() == false)
			{
				
				$estado = False;
				$mensaje = '¡Datos Requeridos!';
			}
			else
			{
				if($this->input->post('tx_token') == $this->session->userdata('tx_token')) { 
				$tx_correo 				= $this->input->post('emailIngreso');
				$tx_clave 				= md5($this->input->post('passwordIngreso'));
				$valida_usuario			= $this->MoUsuarios->valida_usuario($tx_correo,$tx_clave);
				if($valida_usuario)
				{
					$usuario_activo	= $this->MoUsuarios->usuario_activo($tx_correo,$tx_clave);
					if(!$usuario_activo)
					{
					$usuarioeliminado	= $this->MoUsuarios->usuarioeliminado($tx_correo,$tx_clave);
					if($usuarioeliminado==true)
					{	$estado = False;
						$mensaje = '¡Usuario borrado!';
					}
						else
						{
						$estado = False;
						$mensaje = '¡Usuario desactivado!';
						}

					}
					else
					{
					$data = array(
					'in_usuario_hotys' 	=> true,
					'id_usuario' 		=> $valida_usuario->id);
					$this->session->set_userdata($data);
					$estado = True;
					$mensaje = '¡Bienvenido!';
					}
				}
				else{
					$indicador_usuario	= $this->MoUsuarios->indicador_usuario($tx_correo);
					if($indicador_usuario)
					{
						$estado = False;
						$mensaje = 'Contraseña y/o Usuario incorrectos!';

					}
						else{
							$estado = False;
							$mensaje = '¡Usuario no Registrado!';

					}
				}
			}
			else
			{
				$estado = False;
				$mensaje = 'Token vencido!';
			}
			}
		}
		else
		{
			$estado = False;
			$mensaje = 'Contraseña y/o Usuario incorrectos!';
		}
		  echo json_encode($this->respuesta($estado,$mensaje));
	}

	public function token()
	{
		$token = md5(uniqid(rand(),true));
		$this->session->set_userdata('tx_token',$token);
		return $token;
	}


	public function salir()
	{
		$sesionusuario = array(
		'in_usuario_hotys' 	=> false,
		'id_usuario' 	  	=> '',
		'nb_rol_usuario'    => '',
		'co_tipo_usuario'   => '');
		$this->session->unset_userdata($sesionusuario);
		$this->session->sess_destroy();
		redirect('inicio');
	}

	public function respuesta($estado,$mensaje)
	{
		if (!isset($respuesta)) {
			$respuesta = (object)array();}
			$respuesta->resultado = $estado;
			$respuesta->mensaje   = $mensaje;
			return $respuesta;
	}

}
