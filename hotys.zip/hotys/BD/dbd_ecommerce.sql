-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-08-2022 a las 11:42:51
-- Versión del servidor: 8.0.30-0ubuntu0.20.04.2
-- Versión de PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbd_ecommerce`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `c001_orden_detalle`
--

CREATE TABLE `c001_orden_detalle` (
  `id` int UNSIGNED NOT NULL,
  `nu_orden_id` int UNSIGNED NOT NULL,
  `nu_producto_id` int UNSIGNED NOT NULL,
  `nu_precio_producto` float(20,2) NOT NULL DEFAULT '0.00',
  `nu_cantidad_producto` int UNSIGNED NOT NULL,
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `c002_lista_deseo`
--

CREATE TABLE `c002_lista_deseo` (
  `id` int UNSIGNED NOT NULL,
  `nu_producto_id` int UNSIGNED NOT NULL,
  `nu_precio_producto` float(20,2) NOT NULL DEFAULT '0.00',
  `nu_cantidad_producto` int UNSIGNED NOT NULL,
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `c003_producto_opcion`
--

CREATE TABLE `c003_producto_opcion` (
  `id` int UNSIGNED NOT NULL,
  `nu_producto_id` int UNSIGNED NOT NULL,
  `nu_opcion_id` int UNSIGNED NOT NULL,
  `tx_valor_opcion` varchar(200) NOT NULL DEFAULT '0.00',
  `nu_cantidad_producto` int UNSIGNED NOT NULL,
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `c004_producto_categoria`
--

CREATE TABLE `c004_producto_categoria` (
  `id` int UNSIGNED NOT NULL,
  `nu_producto_id` int UNSIGNED NOT NULL,
  `nu_categoria_id` int UNSIGNED NOT NULL,
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `i001t_usuario`
--

CREATE TABLE `i001t_usuario` (
  `id` int UNSIGNED NOT NULL,
  `tx_usuario` varchar(200) NOT NULL,
  `tx_correo` varchar(200) NOT NULL,
  `tx_clave` varchar(200) NOT NULL,
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `in_activo` set('0','1') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '1',
  `nu_rol_id` int UNSIGNED NOT NULL DEFAULT '2',
  `nu_usuario_add_id` int UNSIGNED NOT NULL DEFAULT '1',
  `nu_usuario_upd_id` int UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `i001t_usuario`
--

INSERT INTO `i001t_usuario` (`id`, `tx_usuario`, `tx_correo`, `tx_clave`, `fe_add`, `in_activo`, `nu_rol_id`, `nu_usuario_add_id`, `nu_usuario_upd_id`) VALUES
(1, 'admin', 'admin@hotys.com', '827ccb0eea8a706c4c34a16891f84e7b', '2022-08-16 22:26:05', '1', 1, 1, 1),
(2, 'gamboamej', 'gamboamej@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '2022-08-18 22:48:13', '1', 2, 1, 1),
(3, 'velasquezyos', 'velasquezyos@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '2022-08-18 22:50:25', '1', 2, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `i002t_rol`
--

CREATE TABLE `i002t_rol` (
  `id` int NOT NULL,
  `tx_nb_rol` varchar(200) NOT NULL,
  `in_activo` set('0','1') NOT NULL DEFAULT '1',
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `i002t_rol`
--

INSERT INTO `i002t_rol` (`id`, `tx_nb_rol`, `in_activo`, `fe_add`, `nu_usuario_add_id`, `nu_usuario_upd_id`) VALUES
(1, 'administrador', '1', '2022-08-16 22:51:47', 1, 1),
(2, 'cliente', '1', '2022-08-16 22:51:55', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `i003t_producto`
--

CREATE TABLE `i003t_producto` (
  `id` int UNSIGNED NOT NULL,
  `tx_titulo_producto` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `nu_orden_producto` int UNSIGNED NOT NULL DEFAULT '1',
  `nu_categoria_producto_id` int UNSIGNED NOT NULL DEFAULT '1',
  `in_publicado_producto` set('0','1') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '1',
  `tx_slug_producto` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `tx_tipo_producto` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `tx_url_foto_producto` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `nu_precio_producto` float(20,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `nu_precio_descuento_producto` float(20,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `tx_presentacion_producto` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '100 ml',
  `nu_valoracion_producto` float(1,1) NOT NULL DEFAULT '0.0',
  `fe_add_producto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd_producto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `in_activo` set('0','1') NOT NULL DEFAULT '1',
  `in_descuento_producto` set('0','1') NOT NULL DEFAULT '0',
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `i003t_producto`
--

INSERT INTO `i003t_producto` (`id`, `tx_titulo_producto`, `nu_orden_producto`, `nu_categoria_producto_id`, `in_publicado_producto`, `tx_slug_producto`, `tx_tipo_producto`, `tx_url_foto_producto`, `nu_precio_producto`, `nu_precio_descuento_producto`, `tx_presentacion_producto`, `nu_valoracion_producto`, `fe_add_producto`, `in_activo`, `in_descuento_producto`, `nu_usuario_add_id`, `nu_usuario_upd_id`) VALUES
(1, 'kiss me in the ocean', 1, 1, '1', 'kiss-me-in-the-ocean', 'fragancias', 'pr10.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 09:52:37', '1', '0', 1, 1),
(2, 'big ocean', 11, 1, '1', 'big-ocean', '', 'pr40.jpeg', 40.00, 0.00, '100 ml', 0.0, '2022-08-19 12:02:22', '1', '0', 1, 1),
(3, 'petal edge', 12, 1, '1', 'petal edge', '', 'pr13.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:04:06', '1', '0', 1, 1),
(4, 'for men', 1, 4, '1', 'for men', '', 'pr5.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:24:46', '1', '0', 1, 1),
(5, 'form men (terrific)', 1, 4, '1', 'form men (terrific)', '', 'pr5.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:26:51', '1', '0', 1, 1),
(6, 'sandora', 11, 2, '1', 'sandora', '', 'pr38.jpeg', 40.00, 0.00, '100 ml', 0.0, '2022-08-19 12:27:50', '1', '0', 1, 1),
(7, 'bella rosa', 12, 2, '1', 'bella rosa', '', 'pr36.jpeg', 40.00, 0.00, '100 ml', 0.0, '2022-08-19 12:30:02', '1', '0', 1, 1),
(8, 'body guard', 13, 2, '1', 'body guard', '', 'pr41.jpeg', 40.00, 0.00, '100 ml', 0.0, '2022-08-19 12:31:31', '1', '0', 1, 1),
(9, 'mischief', 14, 2, '1', 'mischief', '', 'pr35.jpeg', 40.00, 0.00, '100 ml', 0.0, '2022-08-19 12:32:43', '1', '0', 1, 1),
(10, 'black tonic', 15, 2, '1', 'black tonic', '', 'pr34.jpeg', 30.00, 0.00, '100 ml', 0.0, '2022-08-19 12:33:58', '1', '0', 1, 1),
(11, 'pack de locion y crema hidratante', 1, 5, '1', 'pack-de-locion-y-crema-hidratante', '', 'pr44.jpeg', 60.00, 0.00, '100 ml', 0.0, '2022-08-19 12:40:30', '1', '0', 1, 1),
(12, 'pure seduction', 2, 1, '1', 'pure-seduction', '', 'pr10.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:47:40', '1', '0', 1, 1),
(13, 'spring poppies', 3, 1, '1', 'spring-poppies', '', 'pr10.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:47:56', '1', '0', 1, 1),
(14, 'tropic rain', 4, 1, '1', 'tropic-rain', '', 'pr10.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:49:21', '1', '0', 1, 1),
(15, 'amber romance', 5, 1, '1', 'amber-romance', '', 'pr7.jpeg', 40.00, 0.00, '100 ml', 0.0, '2022-08-19 12:50:02', '1', '0', 1, 1),
(16, 'punk blooms', 6, 1, '1', 'punk-blooms', '', 'pr7.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:51:32', '1', '0', 1, 1),
(17, 'cremas hidratantes', 7, 1, '1', 'cremas-hidratantes', '', 'pr17.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:52:55', '1', '0', 1, 1),
(18, 'cremas hidratantes 2', 8, 1, '1', 'cremas-hidratantes-2', '', 'pr15.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:54:54', '1', '0', 1, 1),
(19, 'lociones dulces', 9, 1, '1', 'lociones-dulces', '', 'pr2.jpeg', 65.00, 0.00, '100 ml', 0.0, '2022-08-19 12:55:42', '1', '0', 1, 1),
(20, 'lociones dulces 2', 10, 1, '1', 'lociones-dulces-2', '', 'pr1.jpeg', 65.00, 0.00, '100 ml', 0.0, '2022-08-19 12:57:37', '1', '0', 1, 1),
(21, 'amour', 1, 2, '1', 'amour', '', 'pr16.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 12:59:26', '1', '0', 1, 1),
(22, 'plus classe encore', 2, 2, '1', 'plus-classe-encore', '', 'pr21.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:08:40', '1', '0', 1, 1),
(23, 'trendy boy', 3, 2, '1', 'trendy-boy', '', 'pr19.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:09:07', '1', '0', 1, 1),
(24, 'uptown lady', 4, 2, '1', 'uptown-lady', '', 'pr20.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:09:37', '1', '0', 1, 1),
(25, 'sweetie', 5, 2, '1', 'sweetie', '', 'pr25.jpeg', 40.00, 0.00, '100 ml', 0.0, '2022-08-19 13:11:18', '1', '0', 1, 1),
(26, 'grande classe', 6, 2, '1', 'grande-classe', '', 'pr23.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:12:15', '1', '0', 1, 1),
(27, 'miss import rose', 7, 2, '1', 'miss-import-rose', '', 'pr22.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:12:41', '1', '0', 1, 1),
(28, 'pure courage', 8, 2, '1', 'pure-courage', '', 'pr30.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:13:16', '1', '0', 1, 1),
(29, 'mister important', 9, 2, '1', 'mister-important', '', 'pr29.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:13:46', '1', '0', 1, 1),
(30, 'blue and brne', 10, 2, '1', 'blue-and-brne', '', 'pr31.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:14:08', '1', '0', 1, 1),
(31, 'charm', 1, 3, '1', 'charm', '', 'pr32.jpeg', 80.00, 0.00, '100 ml', 0.0, '2022-08-19 13:16:11', '1', '0', 1, 1),
(35, 'concept ii', 1, 5, '1', 'concept-ii', '', 'pr44.jpeg', 60.00, 0.00, '100 ml', 0.0, '2022-08-19 13:20:28', '1', '0', 1, 1),
(37, 'couture', 1, 4, '1', 'couture', '', 'pr4.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:22:39', '1', '0', 1, 1),
(40, 'g for women sexy', 1, 4, '1', 'g-for-women-sexy', '', 'pr3.jpeg', 50.00, 0.00, '100 ml', 0.0, '2022-08-19 13:31:13', '1', '0', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `i004t_categoria`
--

CREATE TABLE `i004t_categoria` (
  `id` int UNSIGNED NOT NULL,
  `tx_nb_categoria` varchar(200) NOT NULL,
  `in_activo` set('0','1') NOT NULL DEFAULT '1',
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `i004t_categoria`
--

INSERT INTO `i004t_categoria` (`id`, `tx_nb_categoria`, `in_activo`, `fe_add`, `nu_usuario_add_id`, `nu_usuario_upd_id`) VALUES
(1, 'Victoria\'s Secret', '1', '2022-08-16 22:52:31', 1, 1),
(2, 'Street Looks', '1', '2022-08-16 22:53:19', 1, 1),
(3, 'Charm', '1', '2022-08-16 22:53:47', 1, 1),
(4, 'Mirage', '1', '2022-08-16 22:54:03', 1, 1),
(5, 'Concept II', '1', '2022-08-19 12:40:01', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `i005t_orden`
--

CREATE TABLE `i005t_orden` (
  `id` int UNSIGNED NOT NULL,
  `nu_monto_orden` float(20,2) NOT NULL,
  `tx_direccion_envio_orden` varchar(200) NOT NULL,
  `tx_correo_envio_orden` varchar(200) NOT NULL,
  `in_orden_estado` set('0','1','2','3','4','5') NOT NULL,
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `i006t_opcion`
--

CREATE TABLE `i006t_opcion` (
  `id` int UNSIGNED NOT NULL,
  `tx_nb_opcion` varchar(200) NOT NULL,
  `in_activo` set('0','1') NOT NULL DEFAULT '1',
  `fe_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fe_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nu_usuario_add_id` int UNSIGNED NOT NULL,
  `nu_usuario_upd_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `c001_orden_detalle`
--
ALTER TABLE `c001_orden_detalle`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `c003_producto_opcion`
--
ALTER TABLE `c003_producto_opcion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `i001t_usuario`
--
ALTER TABLE `i001t_usuario`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `i002t_rol`
--
ALTER TABLE `i002t_rol`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `i003t_producto`
--
ALTER TABLE `i003t_producto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tb003_004_nu_categoria_id` (`nu_categoria_producto_id`);

--
-- Indices de la tabla `i004t_categoria`
--
ALTER TABLE `i004t_categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `i005t_orden`
--
ALTER TABLE `i005t_orden`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `i006t_opcion`
--
ALTER TABLE `i006t_opcion`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `c001_orden_detalle`
--
ALTER TABLE `c001_orden_detalle`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `i001t_usuario`
--
ALTER TABLE `i001t_usuario`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `i002t_rol`
--
ALTER TABLE `i002t_rol`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `i003t_producto`
--
ALTER TABLE `i003t_producto`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT de la tabla `i004t_categoria`
--
ALTER TABLE `i004t_categoria`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `i005t_orden`
--
ALTER TABLE `i005t_orden`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `i006t_opcion`
--
ALTER TABLE `i006t_opcion`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `i003t_producto`
--
ALTER TABLE `i003t_producto`
  ADD CONSTRAINT `fk_tb003_004_nu_categoria_id` FOREIGN KEY (`nu_categoria_producto_id`) REFERENCES `i004t_categoria` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
