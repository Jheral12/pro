var success = $('#frm-save-producto').validate({
    rules: {
        descripcion: {
            required: true,
            minlength: 1,
            maxlength: 50
        },
        precio: {
            required: true,
            minlength: 1,
            maxlength: 50
        },
        foto: {
            required: true,
            minlength: 1,
            maxlength: 200
        },
        categoria: {required: true,minlength:1},
    },
    messages: {
        descripcion: {
            required: "requerido",
            minlength: "Enter between 1 and 30 characters",
            maxlength: "Enter between 1 and 30 characters"
        },
        precio: {
            required: "requerido",
            minlength: "Enter between 1 and 30 characters",
            maxlength: "Enter between 1 and 30 characters"
        },
        categoria: {
            required: "requerido",
            minlength: "requerido",
        },
        foto: {
            required: "requerido",
            minlength: "Enter between 1 and 30 characters",
            maxlength: "Enter between 1 and 30 characters"
        },
    },
    errorElement: 'span',
    errorPlacement: function(error, element) {
        error.addClass('invalid-feedback');
        element.closest('.form-group').append(error);
    },
    highlight: function(element, errorClass, validClass) {
        $(element).addClass('is-invalid');
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).removeClass('is-invalid');
    }
});




$('#frm-save-producto').submit(function(e) {
    e.preventDefault();
    if (success.errorList.length == 0) {
        $.ajax({
            url: baseurl + "producto/save",
            data: $('#frm-save-producto').serialize(),
            type: "post",
            dataType: "json",
            beforeSend: function() {
                Swal.fire({
                    title: '<strong>Cargando</strong>',
                    html: '<img width:"100" height="100" src="assets/imgs/theme/2.png"><h5 class="text-primary"><b>por favor espere...</b></h5>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });
            },
            success: function(data) {
                if (data.resultado == true) {
                    Swal.fire({
                        icon: "success",
                        text: data.mensaje,
                        timer: 2000,
                    }).then(function() {
                   //     window.location.href = baseurl + "administrar";
                     location.reload()
                    });
                    document.getElementById("frm-save-producto").reset();
                //    $("#p_categoria option[value="+ 0 +"]").attr("selected",true);
                } else {
                    Swal.fire({
                        icon: "error",
                        text: data.mensaje,
                        timer: 2000,
                    }).then(function() {
                       // location.reload()
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: "error",
                    text: "Error de Sistema",
      timer: 20000,
                }).then(function() {
          //          location.reload()
                });
            }
        });
    }
});


$('.btn-upd-producto').click(function() {
    $("#id_producto").val(this.getAttribute("data-id"));
    $("#p_descripcion").val(this.getAttribute("data-descripcion"));
    $("#p_precio").val(this.getAttribute("data-precio"));
    $("#p_foto").val(this.getAttribute("data-foto"));
    $("#p_categoria option[value="+ this.getAttribute("data-categoria") +"]").attr("selected",true);
});

$('.btn-del-producto').click(function() {
    var id_del = this.getAttribute("data-id");
 
    $.ajax({
      url: baseurl + "producto/del/" + id_del,
      data: {id: id_del},
      type: "post",
      dataType: "json",
      beforeSend: function() {
        Swal.fire({
        title: '<strong>Cargando...</strong>',
        html: '<img width:"100" height="100" src="assets/imgs/theme/2.png"><h5 class="text-primary"><b>por favor espere...</b></h5>',
        showConfirmButton: false,
        allowOutsideClick: false,
        allowEscapeKey: false});
      },
      success: function(data) {
        if (data.resultado == true) {
          Swal.fire({
            icon: "success",
            text: data.mensaje,
            timer: 2000,}).then(function(){location.reload();});
        } else {
          Swal.fire({icon: "error",text: data.mensaje,timer: 2000,});
        }
      },
      error: function() {
        Swal.fire("Error!", "Error en el servidor", "error");
      }
    });
  });