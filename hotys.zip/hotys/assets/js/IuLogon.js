var success = $('#frmingreso').validate({
    rules: {
        nu_doc: {
            required: true,
            minlength: 1,
            maxlength: 50
        },
        tx_clave: {
            required: true,
            minlength: 1,
            maxlength: 50
        },
    },
    messages: {
        tx_clave: {
            required: "required",
            minlength: "Enter between 1 and 30 characters",
            maxlength: "Enter between 1 and 30 characters"
        },
        nu_doc: {
            required: "required",
            minlength: "Enter between 1 and 30 characters",
            maxlength: "Enter between 1 and 30 characters"
        },
    },
    errorElement: 'span',
    errorPlacement: function(error, element) {
        error.addClass('invalid-feedback');
        element.closest('.form-group').append(error);
    },
    highlight: function(element, errorClass, validClass) {
        $(element).addClass('is-invalid');
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).removeClass('is-invalid');
    }
});

$('#frmingreso').submit(function(e) {
    e.preventDefault();
    event.preventDefault(e);
    if (success.errorList.length == 0) {
        $.ajax({
            url: baseurl + "ingreso",
            data: $('#frmingreso').serialize(),
            type: "post",
            dataType: "json",
            beforeSend: function() {
                Swal.fire({
                    title: '<strong>Cargando</strong>',
                    html: '<img width:"100" height="100" src="assets/imgs/theme/2.png"><h5 class="text-primary"><b>por favor espere...</b></h5>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });
            },
            success: function(data) {
                if (data.resultado == true) {
                    Swal.fire({
                        icon: "success",
                        text: data.mensaje,
                        timer: 2000,
                    }).then(function() {
                        window.location.href = baseurl + "sesion";
                    });
                    document.getElementById("frmingreso").reset();
                } else {
                    Swal.fire({
                        icon: "error",
                        text: data.mensaje,
                        timer: 2000,
                    }).then(function() {
                       // location.reload()
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: "error",
                    text: "Error de Sistema",
      timer: 20000,
                }).then(function() {
          //          location.reload()
                });
            }
        });
    }
});