var success = $('#frmregistro').validate({
    rules: {
        username: {
            required: true,
            minlength: 1,
            maxlength: 50
        },
        email: {
            required: true,
            minlength: 1,
            maxlength: 50
        },
    },
    messages: {
        username: {
            required: "required",
            minlength: "Enter between 1 and 30 characters",
            maxlength: "Enter between 1 and 30 characters"
        },
        email: {
            required: "required",
            minlength: "Enter between 1 and 30 characters",
            maxlength: "Enter between 1 and 30 characters"
        },
    },
    errorElement: 'span',
    errorPlacement: function(error, element) {
        error.addClass('invalid-feedback');
        element.closest('.form-group').append(error);
    },
    highlight: function(element, errorClass, validClass) {
        $(element).addClass('is-invalid');
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).removeClass('is-invalid');
    }
});

$('#frmregistro').submit(function(e) {
    e.preventDefault();
    if (success.errorList.length == 0) {
        $.ajax({
            url: baseurl + "registro",
            data: $('#frmregistro').serialize(),
            type: "post",
            dataType: "json",
            beforeSend: function() {
                Swal.fire({
                    title: '<strong>Cargando</strong>',
                    html: '<img width:"100" height="100" src="assets/imgs/theme/2.png"><h5 class="text-primary"><b>por favor espere...</b></h5>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });
            },
            success: function(data) {
                if (data.resultado == true) {
                    Swal.fire({
                        icon: "success",
                        text: data.mensaje,
                        timer: 2000,
                    }).then(function() {
                        window.location.href = baseurl + "login";
                    });
                    document.getElementById("frmingreso").reset();
                } else {
                    Swal.fire({
                        icon: "error",
                        text: data.mensaje,
                        timer: 2000,
                    }).then(function() {
                       // location.reload()
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: "error",
                    text: "Error de Sistema",
      timer: 20000,
                }).then(function() {
          //          location.reload()
                });
            }
        });
    }
});